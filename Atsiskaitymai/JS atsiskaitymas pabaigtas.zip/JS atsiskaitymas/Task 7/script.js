/* ------------------------------ TASK 7 -----------------------------------
Turimas "audi" objektas.

Parašykite funkciją showObjectKeys, kuri kaip argumentą priims objektą 
ir grąžins visus jo "key" masyve.
-------------------------------------------------------------------------- */
const audi = {
  marke: 'audi',
  model: 'A6',
  year: 2005,
  color: 'white'
};

const showObjectKeys = (audi) => {return Object.keys(audi);}

// sita uzduotis yra audi

// kas bendro tarp joniniu ir audi?
// Lauzas yra