export default function division(a, b) {
  return a / b;
}