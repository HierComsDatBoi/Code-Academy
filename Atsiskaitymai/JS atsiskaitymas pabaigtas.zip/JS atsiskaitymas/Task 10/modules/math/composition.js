export default composition;
function composition(a, b) {
  return a + b;
}