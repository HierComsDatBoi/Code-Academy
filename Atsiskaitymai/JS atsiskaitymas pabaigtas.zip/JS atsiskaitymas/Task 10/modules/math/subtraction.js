export default substraction
 function substraction(a, b) {
  return a - b;
}